import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        String NameOfSomething;

        int NUM =  1;

        String WORD = ("homework");
        NameOfSomething =(NUM + " " + WORD);
        System.out.println( NameOfSomething);

        if (NUM < 0) {
            System.out.println("Вы сохранили отрицательное число");
        } else if (NUM > 0) {
            System.out.println("Вы сохранили положительное число");
        } else {
            System.out.println("Вы сохранили ноль");
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите ваше имя: ");
        String Name = scanner.nextLine();
        System.out.println("Введите вашу фамилию: ");
        String Name2 = scanner.nextLine();
        System.out.println("Привет " + Name + ' ' + Name2 + "!");
    }





}